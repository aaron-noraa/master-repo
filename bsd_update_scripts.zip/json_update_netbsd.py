import requests
from bs4 import BeautifulSoup
import json

BASE_URL = "https://cdn.netbsd.org/pub/NetBSD/iso/amd64/"
OUTPUT_FILE = "netbsd_autogen.json"

def fetch_netbsd_releases():
    print("🌐 Fetching NetBSD release index...")
    resp = requests.get(BASE_URL)
    if resp.status_code != 200:
        print("Failed to fetch NetBSD directory listing.")
        return []

    soup = BeautifulSoup(resp.text, 'html.parser')
    links = soup.find_all('a')
    releases = []

    for link in links:
        href = link.get('href')
        if href and href[0].isdigit():
            version = href.strip('/')
            iso_url = f"{BASE_URL}{href}"
            if iso_url.endswith("/"):
                iso_url = iso_url[:-1]
            releases.append({
                "label": f"NetBSD {version}",
                "codename": "netbsd",
                "version": version,
                "filetype": "ISO",
                "filename": f"netbsd-{version}-amd64.iso",
                "match_hints": [version, "netbsd"],
                "boot_params": "",
                "category": "BSD",
                "variant": "amd64"
            })
    return releases

def save_to_file(data):
    with open(OUTPUT_FILE, "w") as f:
        json.dump(data, f, indent=2)
    print(f"✅ Saved {len(data)} entries to {OUTPUT_FILE}")

if __name__ == "__main__":
    releases = fetch_netbsd_releases()
    save_to_file(releases)
