import requests
from bs4 import BeautifulSoup
import json

BASE_URL = "https://ftp.openbsd.org/pub/OpenBSD/"
OUTPUT_FILE = "openbsd_autogen.json"

def fetch_openbsd_releases():
    print("🧿 Fetching OpenBSD release index...")
    resp = requests.get(BASE_URL)
    if resp.status_code != 200:
        print("Failed to fetch OpenBSD directory listing.")
        return []

    soup = BeautifulSoup(resp.text, 'html.parser')
    links = soup.find_all('a')
    releases = []

    for link in links:
        href = link.get('href')
        if href and href[0].isdigit():
            version = href.strip('/')
            iso_name = f"install{version}.iso"
            releases.append({
                "label": f"OpenBSD {version}",
                "codename": "openbsd",
                "version": version,
                "filetype": "ISO",
                "filename": iso_name,
                "match_hints": [version, "openbsd"],
                "boot_params": "",
                "category": "BSD",
                "variant": "amd64"
            })
    return releases

def save_to_file(data):
    with open(OUTPUT_FILE, "w") as f:
        json.dump(data, f, indent=2)
    print(f"✅ Saved {len(data)} entries to {OUTPUT_FILE}")

if __name__ == "__main__":
    releases = fetch_openbsd_releases()
    save_to_file(releases)
