import requests
from bs4 import BeautifulSoup
import json

BASE_URL = "https://download.freebsd.org/releases/amd64/"
OUTPUT_FILE = "freebsd_autogen.json"

def fetch_freebsd_releases():
    print("🌊 Fetching FreeBSD release index...")
    resp = requests.get(BASE_URL)
    if resp.status_code != 200:
        print("Failed to fetch FreeBSD directory listing.")
        return []

    soup = BeautifulSoup(resp.text, 'html.parser')
    links = soup.find_all('a')
    releases = []

    for link in links:
        href = link.get('href')
        if href and href.endswith('/') and href[0].isdigit():
            version = href.strip('/')
            iso_url = f"{BASE_URL}{href}ISO-IMAGES/"
            iso_resp = requests.get(iso_url)
            if iso_resp.status_code != 200:
                continue
            iso_soup = BeautifulSoup(iso_resp.text, 'html.parser')
            iso_links = iso_soup.find_all('a')
            for iso_link in iso_links:
                iso_name = iso_link.get('href')
                if iso_name and (iso_name.endswith(".iso") or iso_name.endswith(".img")):
                    releases.append({
                        "label": f"FreeBSD {version}",
                        "codename": "freebsd",
                        "version": version,
                        "filetype": "ISO" if iso_name.endswith(".iso") else "IMG",
                        "filename": iso_name,
                        "match_hints": [version, "freebsd"],
                        "boot_params": "",
                        "category": "BSD",
                        "variant": "amd64"
                    })
    return releases

def save_to_file(data):
    with open(OUTPUT_FILE, "w") as f:
        json.dump(data, f, indent=2)
    print(f"✅ Saved {len(data)} entries to {OUTPUT_FILE}")

if __name__ == "__main__":
    releases = fetch_freebsd_releases()
    save_to_file(releases)
